# Development of a Smart Cardiovascular Disease Prediction and Treatment Recommendation System Using Machine Learning and Explainable AI

**Author(s)**: Research Team, HeartCare AI Project  
**Affiliation**: Department of Computer Science & Engineering / Health Informatics  

---

## Abstract

Cardiovascular Diseases (CVDs) remain the leading cause of global mortality, accounting for an estimated 17.9 million deaths annually. While machine learning (ML) classifiers demonstrate strong predictive capabilities for early CVD detection, conventional models operate as uninterpretable "black boxes," restricting their adoption in clinical decision support. 

This paper presents **HeartCare AI**, a novel, end-to-end Explainable AI (XAI) clinical decision-support framework for cardiovascular risk assessment. Trained and validated on a benchmark clinical dataset of 70,000 patient records, our framework compares five distinct classification architectures: Logistic Regression, Support Vector Machine (SVM), Random Forest, Deep Learning Multi-Layer Perceptron (MLP), and XGBoost Classifier. 

Empirical evaluation reveals that **XGBoost Classifier** achieves superior predictive performance with **73.46% accuracy**, **0.7553 precision**, **0.6935 recall/sensitivity**, **0.7756 specificity**, **0.7231 F1-score**, and an **ROC-AUC of 0.8007**. To resolve model opacity, we integrate **SHAP (SHapley Additive exPlanations)** to quantify local and global feature contributions ($\text{SHAP} > 0$ vs. $\text{SHAP} < 0$) and a **Counterfactual AI Optimization Engine** that simulates actionable parameter modifications (e.g., blood pressure, BMI, smoking cessation) to illustrate potential risk reduction deltas ($68.4\% \to 42.7\%$) while holding immutable demographic factors constant. 

The platform incorporates an Optical Character Recognition (OCR) document parser, a multimodal AI health chatbot (supporting text, bilingual voice in English/Hindi, and medicine strip OCR), a camera-based photoplethysmography (PPG) vitals module, a risk-matched doctor recommendation engine, and ReportLab A4 PDF generation. All recommendations are disclaimed as non-prescriptive decision support. 

Our findings demonstrate that combining high-accuracy XGBoost predictions with local SHAP interpretability and counterfactual simulation significantly enhances transparency, auditability, and clinical utility in cardiovascular screening.

**Keywords**—Cardiovascular Disease Prediction, XGBoost, Explainable AI (XAI), SHAP, Counterfactual Explanations, Deep Learning, Clinical Decision Support System (CDSS).

---

## I. Introduction

Cardiovascular diseases (CVDs)—comprising coronary artery disease, cerebrovascular disease, and hypertensive heart disease—constitute the primary driver of premature deaths globally. Early detection of asymptomatic clinical indicators, such as elevated blood pressure, lipid dysregulation, and obesity, is critical for mitigating adverse cardiac events.

Recent advancements in computational intelligence have driven the adoption of supervised machine learning classifiers in medical informatics. However, clinical deployment is obstructed by the "black-box" dilemma: complex gradient boosted ensembles and deep neural networks provide numerical probability scores without offering clinician-auditable explanations. To bridge this gap, this paper introduces **HeartCare AI**, a unified clinical decision-support ecosystem combining high-accuracy ML/DL risk prediction with transparent XAI interpretability and counterfactual scenario simulation.

---

## II. Background and Related Work

Machine learning in cardiovascular risk estimation has evolved from traditional risk charts (e.g. Framingham Risk Score) to non-linear ensemble models. Studies by D'Agostino et al. established baseline statistical risk functions. Recent studies by Chen & Guestrin demonstrated that gradient boosted decision trees (XGBoost) consistently outperform linear methods on tabular clinical datasets. 

In Explainable AI, Lundberg & Lee formulated SHAP (SHapley Additive exPlanations), grounding feature attribution in cooperative game theory. Wachter et al. introduced counterfactual explanations to provide algorithmic recourse. However, existing literature suffers from a disconnect: predictive modeling, explainability, document parsing, and clinical decision support are rarely integrated into a single production-ready web architecture.

---

## III. Problem Statement

Current clinical risk scoring tools suffer from three major deficiencies:
1. **Model Opacity**: High-performing ensemble classifiers lack transparent feature-level explanations.
2. **Lack of Actionable Recourse**: Patients receiving a high risk score are not provided with individual counterfactual scenarios showing how specific lifestyle modifications impact model output.
3. **Fragmented Clinical Workflow**: Data entry, lab report scanning, specialist referral, and reporting exist in silos rather than a unified software system.

---

## IV. Research Gap

Prior research exhibits a gap between high accuracy ML models and actionable clinical usability. Specifically, few frameworks provide:
* Combined **SHAP feature attributions** AND **actionable counterfactual simulations** trained on the same model version.
* Integrated **multimodal interactions** (OCR lab parsing, bilingual voice assistant, medicine strip verification).
* Strict **non-prescriptive medical safety protocols** with emergency symptom override mechanisms.

---

## V. Objectives

The primary objectives of this research are:
1. Train and evaluate five classification architectures (Logistic Regression, SVM, Random Forest, Deep Learning MLP, XGBoost) on 70,000 patient records.
2. Implement local and global **SHAP feature attribution** to explain model predictions.
3. Formulate an **Actionable Counterfactual AI Engine** that calculates simulated risk deltas by optimizing changeable parameters while fixing demographics.
4. Build a full-stack SaaS platform integrating OCR lab parsing, multimodal chatbot, camera PPG, doctor referral, and ReportLab PDF report generation.

---

## VI. Proposed Methodology

The HeartCare AI framework follows a 6-phase pipeline:
1. **Patient Data Acquisition**: Manual 12-feature input or Tesseract/pdfplumber OCR document parsing.
2. **Preprocessing**: Age normalization ($\text{age} / 365.25$), BMI derivation ($\text{weight} / \text{height}^2$), and outlier boundary clipping.
3. **Machine Learning Inference**: Continuous probability scoring via XGBoost ($73.46\%$ accuracy, $0.8007$ ROC-AUC) and 4-tier risk classification (`LOW`, `MODERATE`, `HIGH`, `VERY HIGH`).
4. **SHAP Local Explanation**: Computation of Shapley values quantifying positive ($\text{SHAP} > 0$) and negative ($\text{SHAP} < 0$) risk drivers.
5. **Actionable Counterfactual Simulation**: Optimization of actionable lifestyle/clinical parameters to demonstrate potential risk reduction deltas.
6. **Clinical Decision Support & Report Export**: Categorized guidance, risk-matched doctor referral, and ReportLab A4 PDF generation.

---

## VII. System Architecture

HeartCare AI utilizes a decoupled SaaS architecture:
* **Frontend Layer**: React 18 SPA with Tailwind CSS and Recharts.
* **Backend REST API**: Django 5.1 REST Framework with JWT authentication.
* **ML & XAI Engine**: Scikit-Learn, XGBoost, SHAP `TreeExplainer`, and custom counterfactual optimizer.
* **Document & PDF Layer**: PyTesseract OCR and ReportLab PDF Engine.

---

## VIII. Dataset Description

The system is validated on a benchmark clinical dataset comprising **70,000 patient records** (`backend/ml/dataset/cardiovascular_dataset.csv`).
* **Instances**: 70,000
* **Attributes**: 13 (12 clinical features + 1 target)
* **Missing Values**: 0
* **Target Variable (`cardio`)**: Balanced binary target (35,021 Class 0 [50.03%], 34,979 Class 1 [49.97%]).

---

## IX. Data Preprocessing

Preprocessing is managed by `CVDDataPreprocessor` in `backend/ml/preprocessing.py`:
* Age days converted to years ($\text{age} / 365.25$).
* Height and weight checked against physiological bounds ($100 \le \text{height} \le 220 \text{ cm}$, $30 \le \text{weight} \le 250 \text{ kg}$).
* Blood pressure artifacts clipped ($70 \le \text{ap\_hi} \le 240 \text{ mmHg}$, $40 \le \text{ap\_lo} \le 160 \text{ mmHg}$).

---

## X. Feature Engineering

Twelve final input features are extracted:
`['age_years', 'gender', 'height', 'weight', 'bmi', 'ap_hi', 'ap_lo', 'cholesterol', 'gluc', 'smoke', 'alco', 'active']`.
Body Mass Index ($\text{BMI} = \text{weight} / (\text{height}/100)^2$) captures obesity-related risk.

---

## XI. Machine Learning Models

Five architectures were trained on an 80/20 stratified train/test split:
1. **Logistic Regression**: Linear baseline with $L_2$ regularization.
2. **Support Vector Machine (SVM)**: LinearSVC with calibrated probability output.
3. **Random Forest Classifier**: Ensembled ensemble of 100 decision trees.
4. **Deep Learning MLP**: 2-layer Neural Net (`64x32`) with early stopping.
5. **XGBoost Classifier**: Gradient boosted decision tree ensemble ($150$ trees, max depth $5$, learning rate $0.05$).

---

## XII. Model Training and Evaluation

Model evaluation was executed via `backend/ml/train_model.py` using 14,000 holdout test samples. XGBoost achieved the best overall performance ($73.46\%$ accuracy, $0.8007$ ROC-AUC).

---

## XIII. Explainable Artificial Intelligence (XAI)

To satisfy medical auditability requirements, HeartCare AI integrates dual-level XAI: local feature attribution via SHAP and algorithmic recourse via counterfactual simulation.

---

## XIV. SHAP-Based Explanation

Local SHAP values are computed using `shap.TreeExplainer(model)`:
$$f(x) = \phi_0 + \sum_{i=1}^{M} \phi_i$$
where $\phi_0$ is the base expected value and $\phi_i$ represents feature $i$'s risk contribution. Systolic BP (`ap_hi`, importance $0.38$) and Age (`age_years`, importance $0.22$) emerge as primary risk drivers.

---

## XV. Counterfactual Explanation

The counterfactual engine solves:
$$\arg\min_{x'} d(x, x') \quad \text{s.t.} \quad P(f(x') = 0) \ge \tau$$
holding immutable features ($x_{\text{immut}} = x'_{\text{immut}}$) fixed while modifying actionable variables ($x_{\text{act}}$). In testing, optimizing BP and BMI reduced a patient's risk from $68.4\%$ to $42.7\%$ (Delta $-25.7\%$).

---

## XVI. Decision-Support Recommendation System

The recommendation engine (`backend/recommendations/engine.py`) maps SHAP risk drivers to categorized non-pharmacological guidance across Diet, Exercise, Blood Pressure Monitoring, and Habit Cessation.

---

## XVII. Software Architecture and Implementation

Implemented in Django REST Framework and React 18, the system exposes secure REST endpoints (`/api/predict/`, `/api/reports/upload/`, `/api/doctors/`, `/api/chat/`, `/api/ppg/`, `/api/medical-reports/generate/`).

---

## XVIII. Experimental Results

### Multi-Model Performance Comparison (Test Set N = 14,000)

| Model Architecture | Accuracy | Precision | Recall (Sens.) | Specificity | F1-Score | ROC-AUC |
| :--- | :---: | :---: | :---: | :---: | :---: | :---: |
| Logistic Regression | 71.40% | 0.7315 | 0.6757 | 0.7523 | 0.7025 | 0.7782 |
| Support Vector Machine (SVM) | 64.71% | 0.6558 | 0.6186 | 0.6756 | 0.6367 | 0.7025 |
| Deep Learning (Neural Net MLP) | 72.35% | 0.7206 | **0.7296** | 0.7174 | 0.7251 | 0.7897 |
| Random Forest Classifier | 73.33% | **0.7576** | 0.6857 | **0.7808** | 0.7198 | 0.7974 |
| **XGBoost Classifier (Selected)** | **73.46%** | 0.7553 | 0.6935 | 0.7756 | **0.7231** | **0.8007** |

---

## XIX. Discussion

XGBoost achieved optimal accuracy ($73.46\%$) and ROC-AUC ($0.8007$) due to regularized gradient boosting across tabular features. Deep Learning MLP achieved superior sensitivity ($0.7296$), highlighting its strength in identifying positive cases. The inclusion of SHAP and counterfactuals transforms risk scoring into an actionable, clinician-auditable decision tool.

---

## XX. Limitations

1. **Tabular Dataset Focus**: Validation is currently based on static tabular health records.
2. **Camera PPG Constraints**: Camera-based optical vitals are subject to ambient lighting and motion artifacts, requiring explicit experimental disclaimers.

---

## XXI. Ethical and Medical Safety Considerations

HeartCare AI operates strictly as an educational decision-support prototype. It does not issue definitive medical diagnoses, prescribe medications, or replace licensed physicians. Automated emergency warnings instruct users experiencing chest pain or dyspnea to contact emergency services immediately.

---

## XXII. Future Scope

Future research will focus on prospective clinical trials, wearable IoT sensor streaming (continuous BLE PPG/ECG), and fine-tuned medical LLMs (BioGPT) for clinical dialogue.

---

## XXIII. Conclusion

HeartCare AI demonstrates that combining high-accuracy XGBoost predictions with SHAP interpretability, counterfactual recourse, multimodal OCR/voice interaction, and PDF reporting delivers a robust, transparent clinical decision-support framework.

---

## References

1. S. M. S. Islam et al., "Global burden of cardiovascular diseases, 1990–2019," *JACC*, vol. 76, no. 25, pp. 2982–3021, 2020.
2. S. M. Lundberg and S.-I. Lee, "A unified approach to interpreting model predictions," in *NeurIPS*, 2017, pp. 4765–4774.
3. S. Wachter et al., "Counterfactual explanations without opening the black box," *Harvard J. Law & Tech.*, vol. 31, p. 841, 2017.
4. T. Chen and C. Guestrin, "XGBoost: A scalable tree boosting system," in *ACM SIGKDD*, 2016, pp. 785–794.
5. L. Breiman, "Random forests," *Machine Learning*, vol. 45, no. 1, pp. 5–32, 2001.
6. C. Cortes and V. Vapnik, "Support-vector networks," *Machine Learning*, vol. 20, no. 3, pp. 273–297, 1995.
7. F. Pedregosa et al., "Scikit-learn: Machine learning in Python," *JMLR*, vol. 12, pp. 2825–2830, 2011.
8. R. B. D'Agostino et al., "General cardiovascular risk profile: Framingham Heart Study," *Circulation*, vol. 117, pp. 743–753, 2008.
